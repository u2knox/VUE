<template>
  <div>
    <custom-input
      v-model="fromCustomInput"
    ></custom-input>
    <button @click="addItem">Создать</button>
    <custom-select
      :items="items"
      v-model="selectValue"
    ></custom-select>
    <life-cycle></life-cycle>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from "vue";

import CustomInput from "./components/CustomInput.vue";
import CustomSelect from "./components/CustomSelect.vue";
import LifeCycle from "./components/LifeCycle.vue";

const fromCustomInput = ref("");
const selectValue = ref<string>("");

const items = ref([
  {
    title: "First",
    value: "one",
  },
  {
    title: "Second",
    value: "two",
  },
]);

const addItem = () => {
  items.value.push({
    title: fromCustomInput.value,
    value: fromCustomInput.value,
  })
  fromCustomInput.value = '';
}

</script>

<style scoped></style>
