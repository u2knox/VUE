<template>
  <div>

  </div>
</template>

<script setup lang="ts">
import { computed, beforeCreate } from 'vue';
const test = 1;

const comp = computed(() => 1 + 1);

beforeCreate(() => {
  console.log(comp.value);
})
</script>

<style scoped>

</style>